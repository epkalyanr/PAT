PAT
===

Performance Analysis Tool can be used to gather performance metrics from a Linux machine and plot instant graphs using Microsoft Excel. PAT is easy to install and use by performance engineers and system administrators and doesn't require any programming knowledge.

Software Requirements:
MS Office 2010, 
Linux Systat (version 9.0.4 or newer), 
gawk
